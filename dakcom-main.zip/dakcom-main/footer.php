<div class="footer">
        <section>
            <h3>por qué comprar</h3>
            <p>cómo comprar</p>
            <p>preguntas frecuentes</p>
        </section>
        <section>
            <h3>quiénes somos</h3>
            <p>quiénes somos</p>
            <p>nuestras tiendas</p>
        </section>
        <section>
            <h3>Contactar</h3>
            <p>Centro de soporte</p>
            <p>Contacto</p>
        </section>
        <section>
            <h3>comunidad</h3>
            <a href="https://www.instagram.com/dakcomweb?utm_source=qr">
            <p><i class="fab fa-instagram"></i>instagram</p>
            </a>
            
            <a href="http://www.facebook.com/groups/1267720941170400/">
            <p><i class="fab fa-facebook-square"></i>facebook</p>
            </a>
        </section>
    </div>
    <div class="copy">
        <p>DakCom. Todos los derechos reservados &copy; 2024</p>
    </div>

    <script src="app.js"></script>