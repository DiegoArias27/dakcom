<link rel="stylesheet" href="estilos.css">
<link rel="stylesheet" href="carrito.css">

<nav class="navegador contenedor">
    <img class="icon" src="dakcom.png" width="100px" alt="Logo DakCom">
    <div class="buscador">
        <input type="text" name="" id="" placeholder="En mantenimiento..." disabled>
        <div class="icon-buscar"><i class="fa fa-search icon-buscar" aria-hidden="true"></i></div>
    </div> 
    <ul class="nav contenedor">
        <li>
            <a href="login.html">
                <i class="fa fa-user-circle-o" aria-hidden="true"></i>
                <span class="carrito">Mi cuenta</span>
            </a>
        </li>
        <li>
            <a href="#" id="cartButton">
                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                <span class="carrito">Mi carrito</span>
                <i class="fa fa-circle circulo" aria-hidden="true"></i>
                <span id="cartCount" class="numero" >0</span>
            </a>
        </li>
    </ul>
</nav>

<nav class="all-cat">
    <ul class="contenedor nav2">
        <input type="checkbox" id="btn-menu">
        <li>
            <label for="btn-menu">
                <i class="fa fa-bars" aria-hidden="true"></i>
            </label>
            <span>Todas las categorias</span>
            <ul class="submenu">
                <label for="btn-menu">
                    <i class="fas fa-times-circle"></i></label>
                    <a href="componentes.php"><li>Componentes
                        <ul class="submenu2">
                            <a href="componentes.php"><li>Ver todo Componentes</li></a>
                            <li class="subtitulos-cat">Componentes</li>
                            <a href="procesadores.php"><li>Procesador</li></a>
                            <a href="tarjetas-graficas.php"><li>tarjeta grafica</li></a>
                            <a href="memorias-ram.php"><li>memorias ram</li></a>
                            <a href="placas-base.php"><li>placa madre</li></a>
                            <a href="discos-duros.php"><li>disco duro</li></a>
                            <a href="fuentes-de-poder.php"><li>fuente de poder</li></a>
                            <a href="gabinetes.php"><li>gabinete</li></a>
                        </ul></a>
                    </li>
                    <a href="ordenadores.php"><li>Ordenadores
                        <ul class="submenu2">
                            <a href="ordenadores.php"><li>ver todo ornedadores</li></a>
                            <li class="subtitulos-cat">laptops</li>
                            <a href="portatiles.php"><li>laptop</li></a>
                            <li class="subtitulos-cat">pc's</li>
                            <a href="sobremesa.php"><li>pc</li></a>
                        </ul>
                    </li></a>
                    <a href="perifericos.php"><li>Perifericos
                        <ul class="submenu2">
                            <a href="perifericos.php"><li>ver todo perifericos</li></a>
                            <li class="subtitulos-cat">teclados</li>
                            <a href="teclados.php"><li>teclado</li></a>
                            <li class="subtitulos-cat">mouse</li>
                            <a href="ratones.php"><li>mouse</li></a>
                            <li class="subtitulos-cat">audifonos</li>
                            <a href="audifonos.php"><li>audifonos</li></a>
                        </ul>
                    </li></a>
                    <a href="monitores.php"><li>Monitores
                        <ul class="submenu2">
                            <a href="monitores.php"><li>ver todo monitores</li></a>
                            <li class="subtitulos-cat">monitores</li>
                            <a href="monitores.php"><li>monitor</li></a>
                        </ul>
                    </li></a>
                    <a href="tablets.php"><li>Tablets
                        <ul class="submenu2">
                            <a href="tablets.php"><li>ver todo tablets</li></a>
                            <li class="subtitulos-cat">tablets</li>
                            <a href="tablets.php"><li>tablet</li></a>
                        </ul>
                    </li></a>
                    <a href="celulares.php"><li>Celulares
                        <ul class="submenu2">
                            <a href="celulares.php"><li>ver todo celulares</li></a>
                            <li class="subtitulos-cat">celulares</li>
                            <a href="celulares.php"><li>celular</li></a>
                        </ul>
                    </li></a>
                </ul>
            </li>
    
        <div class="nav21">
            <p>La mejor tienda online servicio, calidad, precio</p>
        </div>
    </ul>
</nav>

<div id="carritoPopup" class="carrito-popup">
    <div class="carrito-contenido" id="carritoContenido">
        <p>No hay productos en el carrito.</p>
    </div>
    <div class="carrito-total">
        <span id="total">Total: $0.00</span>
        <button onclick="vaciarCarrito()">Vaciar carrito</button>
        <button onclick="pagarCarrito()">Pagar</button>
    </div>
</div>

<!-- Modal para el recibo -->
<div id="reciboModal" class="modal">
    <div class="modal-content">
        <span id="closeModal" class="close">&times;</span>
        <h2>Recibo de compra</h2>
        <div id="reciboContenido"></div>
    </div>
</div>

<script>
// Array para almacenar los productos en el carrito
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

// Función para guardar el carrito en localStorage
function guardarCarritoEnLocalStorage() {
    localStorage.setItem('carrito', JSON.stringify(carrito));
}

// Función para agregar productos al carrito
function agregarAlCarrito(producto) {
    const productoExistente = carrito.find(item => item.nombre === producto.nombre);
    if (productoExistente) {
        productoExistente.cantidad += 1;
    } else {
        producto.cantidad = 1;
        carrito.push(producto);
    }
    guardarCarritoEnLocalStorage();
    actualizarCarrito();
}

// Función para actualizar el contador y mostrar el contenido del carrito
function actualizarCarrito() {
    const cartCount = document.getElementById('cartCount');
    cartCount.innerText = carrito.length > 0 ? carrito.length : '0';

    let carritoContenido = document.getElementById('carritoContenido');
    carritoContenido.innerHTML = '';
    let totalCarrito = 0;

    if (carrito.length === 0) {
        carritoContenido.innerHTML = '<p>No hay productos en el carrito.</p>';
    } else {
        carrito.forEach(producto => {
            const divProducto = document.createElement('div');
            divProducto.classList.add('producto-carrito');
            divProducto.innerHTML = `
                <img src="${producto.img}" alt="${producto.nombre}" class="producto-imagen">
                <div class="producto-info">
                    <h4>${producto.nombre}</h4>
                    <p>$${producto.precio}</p>
                    <p>Cantidad: 
                        <button class="cantidad-btn" onclick="modificarCantidad('${producto.nombre}', -1)">-</button>
                        ${producto.cantidad}
                        <button class="cantidad-btn" onclick="modificarCantidad('${producto.nombre}', 1)">+</button>
                    </p>
                    <p>Total: $${(producto.precio * producto.cantidad).toFixed(2)}</p>
                </div>
            `;
            carritoContenido.appendChild(divProducto);
            totalCarrito += producto.precio * producto.cantidad;
        });
    }

    const totalElemento = document.getElementById('total');
    totalElemento.innerText = `Total: $${totalCarrito.toFixed(2)}`;
}

// Función para modificar la cantidad de un producto en el carrito
function modificarCantidad(nombreProducto, cantidad) {
    const producto = carrito.find(item => item.nombre === nombreProducto);
    if (producto) {
        if (producto.cantidad + cantidad > 0) {
            producto.cantidad += cantidad;
        } else {
            carrito = carrito.filter(item => item.nombre !== nombreProducto);
        }
    }
    guardarCarritoEnLocalStorage();
    actualizarCarrito();
}

// Mostrar el carrito al hacer clic en "Mi carrito"
document.getElementById('cartButton').addEventListener('click', function() {
    let carritoDiv = document.getElementById('carritoPopup');
    carritoDiv.style.display = carritoDiv.style.display === 'block' ? 'none' : 'block';
});

// Función para vaciar el carrito
function vaciarCarrito() {
    carrito = [];
    guardarCarritoEnLocalStorage();
    actualizarCarrito();
    document.getElementById('carritoPopup').style.display = 'none';
}

// Función para generar el recibo al pagar
function pagarCarrito() {
    let reciboContenido = document.getElementById('reciboContenido');
    reciboContenido.innerHTML = '<h3>Gracias por tu compra</h3>';
    carrito.forEach(producto => {
        reciboContenido.innerHTML += `
            <p>${producto.nombre} x ${producto.cantidad} - $${(producto.precio * producto.cantidad).toFixed(2)}</p>
        `;
    });

    const totalCompra = carrito.reduce((total, producto) => total + (producto.precio * producto.cantidad), 0);
    reciboContenido.innerHTML += `<p>Total: $${totalCompra.toFixed(2)}</p>`;
    
    // Mostrar modal del recibo
    document.getElementById('reciboModal').style.display = 'block';
}

// Cerrar el modal del recibo
document.getElementById('closeModal').addEventListener('click', function() {
    document.getElementById('reciboModal').style.display = 'none';
});

// Inicializar el carrito al cargar la página
actualizarCarrito();
    


</script>
